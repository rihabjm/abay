import { Component, OnInit } from '@angular/core';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';
import {AuthenticationService} from '../Service/authentication.service';
import {Utilisateur} from '../Model/utilisateur';
import {UtilisateurService} from '../Service/utilisateur.service';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
  providers: [NgbDropdownConfig]
})
export class NavbarComponent implements OnInit {
  public sidebarOpened = false;
  toggleOffcanvas() {
    this.sidebarOpened = !this.sidebarOpened;
    if (this.sidebarOpened) {
      document.querySelector('.sidebar-offcanvas').classList.add('active');
    }
    else {
      document.querySelector('.sidebar-offcanvas').classList.remove('active');
    }
  }

  constructor(config: NgbDropdownConfig ,private auth: AuthenticationService, private userService :UtilisateurService) {
    config.placement = 'bottom-right';
  }
   role :String ;

    user: Utilisateur = new Utilisateur();

  user1 : Utilisateur = new Utilisateur();
  ngOnInit() {
 this.userService.getUser().subscribe( res => {
      this.user = res;
    }, ex => {
      console.log(ex);
    });

    if (this.auth.isAdmin() === true) {
      this.role = "Admin";
    } else  if (this.auth.isUser() === true) {
      this.role = "Utilisateur";
    }
    if (this.auth.getRole() === 'Formateur') {
      this.role = "formateur";
    }



  }

}
