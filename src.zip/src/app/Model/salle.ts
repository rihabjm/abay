export class Salle {
  	idsalle : number ;
     capacitesalle :number ;
numsalle : number ;
occupe : boolean ;
}
