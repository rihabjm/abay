import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {Promotion} from '../../../Model/promotion';
import {PromotionService} from '../../../Service/promotion.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import {Formation} from '../../../Model/formation';
import {FormationService} from '../../../Service/formation.service';
import {Remise} from '../../../Model/remise';
import {RemiseService} from '../../../Service/remise.service';
@Component({
  selector: 'app-choisirpromotion',
  templateUrl: './choisirpromotion.component.html',
  styleUrls: ['./choisirpromotion.component.scss']
})
export class ChoisirpromotionComponent implements OnInit {

 temp =new Array();
 remise :Remise= new Remise();

  constructor( private remiseservice :RemiseService ,private _Activatedroute:ActivatedRoute, private router: Router ,private promotionService: PromotionService , private formationservice :FormationService) { }
   sub;
   promotion :Promotion ;
   formation :Formation ;
   id ;
   formations : Formation[] = new Array();
   formationselectionne  : Formation[] =new Array();



  ngOnInit() {
   this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.promotionService.getpromotion(this.id)
      .subscribe(data => {
        console.log(data)
        this.promotion = data[0];
      }, error => console.log(error));

      });

       this.getAll();
       }


private getAll() {
 this.formationservice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}


 choisir(formationslct :Formation)
 {
  this.formationselectionne.push(formationslct) ;
  console.log(formationslct);
 }


affecter(remise :Remise)
{
for(let i=0;i<this.formationselectionne.length ;i++)
{

this.remiseservice.add(remise,this.id,this.formationselectionne[i].idformation).subscribe(data => {

    }, ex => {
      console.log(ex);
    });;
}
}
}
