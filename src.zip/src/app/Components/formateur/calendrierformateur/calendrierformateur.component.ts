import { Inject ,Component, OnInit } from '@angular/core';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import * as $ from 'jquery';
@Component({
  selector: 'app-calendrierformateur',
  templateUrl: './calendrierformateur.component.html',
  styleUrls: ['./calendrierformateur.component.scss']
})
export class CalendrierformateurComponent implements OnInit {

constructor( private formateurservice :FormateurService ) { }

ngOnInit() {

}
}
