 import { Component, OnInit , ViewEncapsulation, ChangeDetectorRef , Input } from '@angular/core';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import {Specilaite} from '../../../Model/Specilaite';
import {SpecialiteService} from '../../../Service/specialite.service';
import {FormControl,FormGroup,FormBuilder ,NgForm, ReactiveFormsModule,Validators, NgControl,ValidationErrors ,FormsModule } from '@angular/forms';
import { HttpClient, HttpEventType  ,HttpResponse} from '@angular/common/http';
import {FileService} from '../../../Service/file.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {UploadfileService} from '../../../Service/uploadfile.service';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-ajoutformateur',
  templateUrl: './ajoutformateur.component.html',
  styleUrls: ['./ajoutformateur.component.scss']
})
export class AjoutformateurComponent implements OnInit {

  dropdownList = [];
  selectedItems = [];
   selection = [];
   message :String ;
 temp =new Array();
 specialites: Specilaite[] = new Array();
 specialiteschoisi: Specilaite[] = new Array();


onItemSelect(item: any) {
    console.log(item);
    this.selection.push(item);
     this.formateurService.affectspecialite(item.item_text ,1).subscribe( data => {
            });
  }
  onSelectAll(items: any) {
    console.log(items);
  }
constructor(private uploadService : UploadfileService,   private modalService: NgbModal  , private changeDetect: ChangeDetectorRef  ,private httpClient: HttpClient , private formateurService: FormateurService, private FileService :FileService , private specialiteService :SpecialiteService   ) { }
  formateur : Formateur =new Formateur() ;
   selectedFile: File;


 id : number ;

    submitted = false;
  ngOnInit() {
   this.submitted=false;
  this.getspecialite();

}



       Ajouter(formateur :Formateur ,compethence ) {
       this.modalService.open(compethence);
         this.formateurService.save(this.formateur).subscribe( data => {
          this.id=data.id ;

    this.message="Formateur ajouté" ;

    }, ex => {
    this.message="Echec d'ajout" ;
      console.log(ex);
    });
       }





 public onFileChanged(event) {
    //Select File
    this.selectedFile = event.target.files[0];
  }

  getspecialite()
  {
    this.specialiteService.list().subscribe((data: any) => {
    this.specialites=data ;

       });
  }


  specialiteselectionner :Specilaite  ;





 selectedFiles: FileList;
  currentFileUpload: File;
  progress: { percentage: number } = { percentage: 0 };
sp :number ;

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }


 private upload() {
    this.progress.percentage = 0;

    this.currentFileUpload = this.selectedFiles.item(0);
    this.uploadService.pushFileToStoragecv(this.currentFileUpload,this.id ).subscribe(event => {

    });

    this.selectedFiles = undefined;
  }

  private uploadcertif() {
    this.progress.percentage = 0;

    this.currentFileUpload = this.selectedFiles.item(0);
    this.uploadService.pushFileToStoragecertificat(this.currentFileUpload,this.id,this.sp).subscribe(event => {

    });
 this.formateurService.affectspecialite(this.sp,this.id).subscribe( data => {
            });
    this.selectedFiles = undefined;
  }




showFile = false;
  fileUploads: Observable<string[]>;

private   showFilesCv(enable: boolean) {
    this.showFile = enable;

    if (enable) {
      this.fileUploads = this.uploadService.getFilesCv(this.id);
    }
  }



 @Input() fileUpload: string;


}


