import {Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild, ViewEncapsulation} from '@angular/core';
import {EmailValidator, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Utilisateur} from '../../../Model/utilisateur';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {error} from 'util';
import {UtilisateurService} from '../../../Service/utilisateur.service';
import {Router} from "@angular/router";


type Type = 'text' | 'password' ;


// la fonction de password et confirm password
export function MustMatch(controlName: string, matchingControlName: string) {
  return (formGroup: FormGroup) => {
    const control = formGroup.controls[controlName];
    const matchingControl = formGroup.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
      // return if another validator has already found an error on the matchingControl
      return;
    }

    // set error on matchingControl if validation fails
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  };
}

@Component({
  selector: 'app-registre',
  templateUrl: './registre.component.html',
  styleUrls: ['./registre.component.scss']
})
export class RegistreComponent implements OnInit {

  user: Utilisateur = new Utilisateur();






  constructor(private formBuilder: FormBuilder, private route: Router, private userService: UtilisateurService) {
  }

  ngOnInit() {



  }

  add() {
    this.userService.add(this.user).subscribe(data => console.log(data), error1 => console.log(error1));


  }
}
