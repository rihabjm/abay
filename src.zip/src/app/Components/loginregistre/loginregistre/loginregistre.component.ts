import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginregistre',
  templateUrl: './loginregistre.component.html',
  styleUrls: ['./loginregistre.component.scss']
})
export class LoginregistreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
