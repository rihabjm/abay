import { TestBed } from '@angular/core/testing';

import { ProgrammekhdemniService } from './programmekhdemni.service';

describe('ProgrammekhdemniService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProgrammekhdemniService = TestBed.get(ProgrammekhdemniService);
    expect(service).toBeTruthy();
  });
});
