import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Files} from '../Model/files';
@Injectable({
  providedIn: 'root'
})
export class FileService {
 constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL;
private urld = this.url + '/upload';
private urldformation = this.url + '/uploadimageformation';
private urlcertificat = this.url + '/uploadcertificatspecialite';

private urlcv = this.url + '/uploadcvformateur';

  uploadFile(product: object, idCategory: number): Observable<object> {
    return this.httpClient.post(`${this.urld}/${idCategory}`, product);
  }
  uploadFileformation(product: object, idCategory: number): Observable<object> {
    return this.httpClient.post(`${this.urldformation}/${idCategory}`, product);
  }
   uploadFileformateurcv(product: object, idCategory: number): Observable<object> {
    return this.httpClient.post(`${this.urlcv}/${idCategory}`, product);
  }
  uploadFileformateurcertificat(product: object, idCategory: number): Observable<object> {
    return this.httpClient.post(`${this.urlcertificat}/${idCategory}`, product);
  }


 public save(files:Files): Observable<any> {

  return this.httpClient.post(this.url+'/uploadFile',files );
  }

}
